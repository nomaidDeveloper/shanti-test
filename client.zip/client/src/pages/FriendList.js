import React, { useState, useEffect } from 'react';
import axios from 'axios';

function FriendList() {
  const [friends, setFriends] = useState([]);

  useEffect(() => {
    const fetchFriends = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/user/friends', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        setFriends(response.data);
      } catch (error) {
        console.error('Fetch friends error', error.response.data);
      }
    };
    fetchFriends();
  }, []);

  const removeFriend = async (friendId) => {
    try {
      await axios.delete(`http://localhost:8000/api/user/friends/${friendId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setFriends(friends.filter(friend => friend.id !== friendId));
    } catch (error) {
      console.error('Remove friend error', error.response.data);
    }
  };

  return (
    <ul>
      {friends.map(friend => (
        <li key={friend.id}>
          {friend.name} - {friend.email}
          <button onClick={() => removeFriend(friend.id)}>Remove Friend</button>
        </li>
      ))}
    </ul>
  );
}

export default FriendList;