import React, { useState, useEffect } from 'react';
import axios from 'axios';

function FriendRequests() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/user/friend-requests', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        console.log(response,"response");
        
        setRequests(response.data);
      } catch (error) {
        console.error('Fetch requests error', error.response.data);
      }
    };
    fetchRequests();
  }, []);

  const handleRequest = async (requestId, action) => {
    try {
      await axios.post(`http://localhost:8000/api/user/friend-requests/${requestId}/${action}`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setRequests(requests.filter(request => request.id !== requestId));
    } catch (error) {
      console.error(`${action} request error`, error.response.data);
    }
  };

  return (
    <ul>
      {requests.map(request => (
        <li key={request.id}>
          {request.name} - {request.email}
          <button onClick={() => handleRequest(request.id, 'accept')}>Accept</button>
          <button onClick={() => handleRequest(request.id, 'reject')}>Reject</button>
        </li>
      ))}
    </ul>
  );
}

export default FriendRequests;