import React from 'react';
import { Link, useNavigate } from 'react-router-dom';


function Home() {
  const navigate = useNavigate();

  const handleViewProfile = () => {
    const userId = localStorage.getItem('userId');
    if (userId) {
      // Redirect to the user's profile page
      navigate(`/profile/${userId}`);
    } else {
      // Optionally handle the case where userId is not found
      console.error('User ID not found in localStorage');
    }
  };
  const handleLogout = () => {
    // Clear the token from localStorage
    localStorage.removeItem(process.env.REACT_APP_LOCALHOST_KEY);

    // Redirect to the login page
    navigate('/login');
  };

  return (
    <div className="home-container">
      <h1>Welcome to the Social Network</h1>
      <p>Your hub for connecting with friends and exploring new people.</p>
      
      <div className="home-actions">
        {/* <Link to="/profile/" className="btn">View Profile</Link> */}
        <button onClick={handleViewProfile} className="btn">View Profile</button>
        <Link to="/search" className="btn">Search Friends</Link>
        <Link to="/friends" className="btn">Friend List</Link>
        <Link to="/requests" className="btn">Friend Requests</Link>
        <button onClick={handleLogout} className="btn btn-logout">Logout</button>
      </div>
      
      <div className="home-footer">
        <p>Explore, connect, and have fun!</p>
      </div>
    </div>
  );
}

export default Home;
