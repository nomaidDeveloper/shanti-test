const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
// const { User } = require('../models');
const { User } = require('../db');
const nodemailer = require('nodemailer');
const { Op } = require('sequelize');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const authController = {

  async signIn(req, res) {
    try {
      console.log(req.body);
      
      const { email = undefined, mobile = undefined, password } = req.body;
      const user = await User.findOne({
        where: email ? { email } : { mobile }
      });
  
      if (!user || !bcrypt.compareSync(password, user.password)) {
        return res.status(400).json({ message: 'Invalid credentials' });
      }
  
      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1d' });
      res.json({ status: true, token, user });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },
  
  // async signIn(req, res) {
  //   try {
  //     console.log(req.body);
      
  //     const { email = undefined, mobile=undefined, password } = req.body;
  //     const user = await User.findOne({
  //       where: email ? { email } : { mobile }
  //     });

  //     if (!user || !bcrypt.compareSync(password, user.password)) {
  //       return res.status(400).json({ message: 'Invalid credentials' });
  //     }

  //     const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '10m' });
  //     res.json({ token });
  //   } catch (error) {
  //     console.error(error);
  //     res.status(500).json({ message: 'Server error' });
  //   }
  // },

  async refreshToken(req, res) {
    try {
      const { token } = req.body;
      if (!token) {
        return res.status(400).json({ message: 'Token is required' });
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const newToken = jwt.sign({ id: decoded.id }, process.env.JWT_SECRET, { expiresIn: '10m' });
      res.json({ token: newToken });
    } catch (error) {
      console.error(error);
      res.status(400).json({ message: 'Invalid token' });
    }
  },

  async requestPasswordReset(req, res) {
    try {
      const { email } = req.body;
      const user = await User.findOne({ where: { email } });

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const resetOtp = Math.floor(100000 + Math.random() * 900000).toString();
      const otpExpiration = new Date(Date.now() + 10 * 60 * 1000);

      user.resetOtp = resetOtp;
      user.resetOtpExpiration = otpExpiration;
      await user.save();

      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: user.email,
        subject: 'Password Reset OTP',
        text: `Your OTP for password reset is: ${resetOtp}. It will expire in 10 minutes.`
      });

      res.json({ message: 'OTP sent to email' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  async resetPassword(req, res) {
    try {
      const { email, otp, newPassword } = req.body;
      const user = await User.findOne({
        where: {
          email,
          resetOtp: otp,
          resetOtpExpiration: { [Op.gt]: new Date() }
        }
      });

      if (!user) {
        return res.status(400).json({ message: 'Invalid or expired OTP' });
      }

      user.password = bcrypt.hashSync(newPassword, 10);
      user.resetOtp = null;
      user.resetOtpExpiration = null;
      await user.save();

      res.json({ message: 'Password reset successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // async signUp(req, res) {
  //   try {
  //     const { email, mobile, password, name, address, latitude, longitude } = req.body;
  //     const existingUser = await User.findOne({
  //       where: {
  //         [Op.or]: [{ email }, { mobile }]
  //       }
  //     });

  //     if (existingUser) {
  //       return res.status(400).json({ message: 'User with this email or mobile already exists' });
  //     }

  //     const hashedPassword = bcrypt.hashSync(password, 10);
  //     const user = await User.create({
  //       email,
  //       mobile,
  //       password: hashedPassword,
  //       name,
  //       address,
  //       latitude,
  //       longitude
  //     });

  //     res.status(200).json({
  //       statusCode: 200,
  //       message: 'User created successfully',
  //       result: user
  //     });
  //   } catch (error) {
  //     console.error(error);
  //     res.status(500).json({ message: 'Server error' });
  //   }
  // }
  async signUp(req, res) {
    try {
      const { email, mobile, password, name, address, latitude, longitude } = req.body;
  
      // Check for existing user
      const existingUser = await User.findOne({
        where: {
          [Op.or]: [{ email }, { mobile }]
        }
      });
  
      if (existingUser) {
        return res.status(400).json({ status: false, message: 'User with this email or mobile already exists' });
      }
  
      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Create the user
      const user = await User.create({
        email,
        mobile,
        password: hashedPassword,
        name,
        address,
        latitude,
        longitude
      });
  
      // Generate a JWT token
      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '10m' });
  
      res.status(200).json({
        status: true,
        message: 'User created successfully',
        user,
        token
      });
    } catch (error) {
      console.error(error);
  
      if (error.name === 'SequelizeValidationError' || error.name === 'SequelizeUniqueConstraintError') {
        // Handle Sequelize validation errors
        return res.status(400).json({ status: false, message: error.errors.map(e => e.message).join(', ') });
      }
  
      res.status(500).json({ status: false, message: 'Server error' });
    }
  }
  
};

module.exports = authController;