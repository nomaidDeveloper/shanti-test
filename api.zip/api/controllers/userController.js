// const { User } = require('../models/User');
const { User ,FriendRequest} = require('../db');
const { Op } = require('sequelize');

const userController = {
  // Update profile
  async updateProfile(req, res) {
    try {
      const { name, address, latitude, longitude } = req.body;
      const userId = req.user.id;

      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      user.name = name || user.name;
      user.address = address || user.address;
      user.latitude = latitude || user.latitude;
      user.longitude = longitude || user.longitude;

      await user.save();

      res.json({ message: 'Profile updated successfully', user });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },


  async searchFriends(req, res) {
    try {
      const { query, distance } = req.query;
      const userId = req.user.id;
  
      let whereClause = {
        id: { [Op.ne]: userId } // Exclude the current user
      };
  
      if (query) {
        whereClause = {
          ...whereClause,
          [Op.or]: [
            { name: { [Op.like]: `%${query}%` } },
            { email: { [Op.like]: `%${query}%` } },
            { mobile: { [Op.like]: `%${query}%` } }
          ]
        };
      }
  
      const users = await User.findAll({
        where: whereClause,
        attributes: ['id', 'name', 'email', 'mobile', 'latitude', 'longitude'],
        include: [
          {
            model: User,
            as: 'Friends',
            where: { id: userId },
            required: false
          }
        ]
      });
  
      // Filter out users who are already friends
      const potentialFriends = users.filter(user => user.Friends.length === 0);
  
      // If distance is provided, filter based on distance
      if (distance) {
        const currentUser = await User.findByPk(userId);
        const filteredUsers = potentialFriends.filter(user => {
          const userDistance = calculateDistance(
            currentUser.latitude, currentUser.longitude,
            user.latitude, user.longitude
          );
          return userDistance <= distance;
        });
        return res.json(filteredUsers);
      }
  
      res.json(potentialFriends);
    } catch (error) {
      console.error('Search error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },
  // Friend list
  async getFriendList(req, res) {
    try {
      const userId = req.user.id;

      const user = await User.findByPk(userId, {
        include: [
          {
            model: User,
            as: 'Friends',
            attributes: ['id', 'name', 'email', 'mobile']
          }
        ]
      });

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json(user.Friends);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Remove friend
  async removeFriend(req, res) {
    try {
      const userId = req.user.id;
      const friendId = req.params.friendId;

      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      await user.removeFriend(friendId);

      res.json({ message: 'Friend removed successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get friend requests
  async getFriendRequests(req, res) {
    try {
      const userId = req.user.id;
  
      const user = await User.findByPk(userId, {
        include: [
          {
            model: User,
            as: 'ReceivedFriendRequests',
            attributes: ['id', 'name', 'email', 'mobile'],
            through: {
              attributes: [] // Exclude attributes from the join table
            }
          }
        ]
      });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      res.json(user.ReceivedFriendRequests);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },
  
  

  // Accept friend request
  async acceptFriendRequest(req, res) {
    try {
      const userId = req.user.id;
      const requestId = req.params.requestId;

      const user = await User.findByPk(userId);
      const friend = await User.findByPk(requestId);

      if (!user || !friend) {
        return res.status(404).json({ message: 'User or friend not found' });
      }

      await user.addFriend(friend);
      await user.removeFriendRequest(friend);

      res.json({ message: 'Friend request accepted' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Reject friend request
  async rejectFriendRequest(req, res) {
    try {
      const userId = req.user.id;
      const requestId = req.params.requestId;

      const user = await User.findByPk(userId);
      const friend = await User.findByPk(requestId);

      if (!user || !friend) {
        return res.status(404).json({ message: 'User or friend not found' });
      }

      await user.removeFriendRequest(friend);

      res.json({ message: 'Friend request rejected' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // View profile
  async viewProfile(req, res) {
    try {
      const id = req.params.userId;
      console.log(`Fetching profile for id: ${id}`);
  
      const user = await User.findByPk(id, {
        attributes: ['id', 'name', 'email', 'mobile', 'address', 'latitude', 'longitude']
      });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      res.json(user);
    } catch (error) {
      console.error('Error fetching profile:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Send friend request
  async sendFriendRequest(req, res) {
    try {
      const userId = req.user.id;
      const friendId = req.params.friendId;
  
      // Ensure both users exist
      const user = await User.findByPk(userId);
      const friend = await User.findByPk(friendId);
  
      if (!user || !friend) {
        return res.status(404).json({ message: 'User or friend not found' });
      }
  
      // Check if a friend request already exists
      const existingRequest = await FriendRequest.findOne({
        where: {
          senderId: userId,
          receiverId: friendId,
        },
      });
  
      if (existingRequest) {
        return res.status(400).json({ message: 'Friend request already sent' });
      }
  
      // Create a new friend request
      await FriendRequest.create({
        senderId: userId,
        receiverId: friendId,
      });
  
      res.json({ message: 'Friend request sent' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  }
};

// Helper function to calculate distance between two points
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the Earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  return distance;
}

module.exports = userController;