module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', {
      mobile: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
          is: /^[0-9]{10}$/
        }
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      address: {
        type: DataTypes.STRING,
      },
      latitude: {
        type: DataTypes.FLOAT,
      },
      longitude: {
        type: DataTypes.FLOAT,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
          isEmail: true,
        }
      },
      resetOtp: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      resetOtpExpiration: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    });
 
    User.associate = models => {
      // Friends through UserFriends
      User.belongsToMany(User, {
        as: 'Friends',
        through: 'UserFriends',
        foreignKey: 'userId',
        otherKey: 'friendId',
      });
  
      // Received Friend Requests through FriendRequestsReceived
      User.belongsToMany(User, {
        as: 'ReceivedFriendRequests',
        through: 'FriendRequestsReceived',
        foreignKey: 'receiverId',
        otherKey: 'senderId',
      });
  
      // Sent Friend Requests through FriendRequestsSent
      User.belongsToMany(User, {
        as: 'SentFriendRequests',
        through: 'FriendRequestsSent',
        foreignKey: 'senderId',
        otherKey: 'receiverId',
      });
  
      // Associations with FriendRequest model
      User.hasMany(models.FriendRequest, {
        as: 'SentRequests', // Changed alias to avoid conflict
        foreignKey: 'senderId',
      });
  
      User.hasMany(models.FriendRequest, {
        as: 'ReceivedRequests', // Changed alias to avoid conflict
        foreignKey: 'receiverId',
      });
    }

    return User;
  };
  