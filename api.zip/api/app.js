require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { sequelize } = require('./db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');

const app = express();

// app.use(cors());4
app.use(cors({
    origin: 'http://localhost:3000', // Adjust according to your frontend's URL
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
  }));
app.use(express.json());

sequelize
    .sync()
    .then(() => {
        console.log('DB Connection Successful');
    })
    .catch((err) => {
        console.error(err.message);
    });

app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);

const PORT = process.env.PORT || 8000;

app.listen(PORT, () => {
    console.log(`Server started on ${PORT}`);
});
